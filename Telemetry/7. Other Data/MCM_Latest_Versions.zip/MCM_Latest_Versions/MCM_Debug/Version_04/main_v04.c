// ******************************************************************************** //
// ******************************* Program : MCM_Debug **************************** //
// *********************************** Version : 04 ******************************* //
// ******************************* Date : 02/02/2014 ****************************** //
// ********* Only web based program, serving monitoring and controlling  ********** //
// ********* web pages for maintenance and troubleshooting of MCM in Lab ********** //
// ******************************************************************************** //


#class  auto
#memmap xmem

#define TCPCONFIG			0
#define USE_ETHERNET		1
#define MY_IP_ADDR      "192.168.8.233"
#define MY_NET_MASK     "255.255.255.0"
#define MY_GATEWAY      "192.168.8.1"

#define TCP_BUF_SIZE   	4096    // By-Default TCP_BUF_SIZE : 4096 //
#define MAX_SOCKETS     2
#define MAX_TCP_SOCKET_BUFFERS 2

#define ADC_SCLKBRATE 	115200ul
#define GAINSET 		   GAIN_1
#define SCAN_DELAY		400

#define SPI_SER_D
#define SPI_RX_PORT SPI_RX_PD
#define SPI_CLK_DIVISOR 100

#define USE_RABBITWEB 1
#define USE_HTTP_BASIC_AUTHENTICATION 1

#use   "dcrtcp.lib"
#use   "rcm43xx.lib"	             // Use with RCM 4300
#use   "http.lib"
#use   "spi.lib"
#use   "adc_ads7870.lib"

#ximport  "MCM_Mon.zhtml"   MCM_Mon_zhtml
#ximport  "Mon_Raw.xml"     Mon_Raw_xml
#ximport  "Mon_Sum.xml"     Mon_Sum_xml
#ximport  "MCM_Set.zhtml"   MCM_Set_zhtml


SSPEC_MIMETABLE_START
   SSPEC_MIME_FUNC(".zhtml","text/html",zhtml_handler),
   SSPEC_MIME_FUNC(".xml","text/xml",zhtml_handler),
   SSPEC_MIME(".html","text/html")
SSPEC_MIMETABLE_END

SSPEC_RESOURCETABLE_START
   SSPEC_RESOURCE_XMEMFILE("/",MCM_Mon_zhtml),
   SSPEC_RESOURCE_XMEMFILE("/Mon_Sum.xml",Mon_Sum_xml),
   SSPEC_RESOURCE_XMEMFILE("/Mon_Raw.xml",Mon_Raw_xml),
	SSPEC_RESOURCE_XMEMFILE("/MCM_Set.zhtml",MCM_Set_zhtml)
SSPEC_RESOURCETABLE_END


void Set_LO();
void Set_SS();
void Set_FDB();
void Set_FDV();
void Set_DMask();
void Set_NW();
void Rd_MCM_Clk();
int  atox(char *);
void Scan();

char ip[20], mask[20], gateway[20];
#web ip
#web mask
#web gateway

int LO1, LO2, Temp_LO1, Temp_LO2;
#web LO1  select("Choose LO1" = 0, "600 MHZ","650 MHZ","700 MHZ","750 MHZ","800 MHZ","850 MHZ","900 MHZ","950 MHZ","1000 MHZ","1050 MHZ","1100 MHZ","1150 MHZ","1200 MHZ","1250 MHZ","1300 MHZ","1350 MHZ","1400 MHZ")
#web LO2  select("Choose LO2" = 0, "600 MHZ","650 MHZ","700 MHZ","750 MHZ","800 MHZ","850 MHZ","900 MHZ","950 MHZ","1000 MHZ","1050 MHZ","1100 MHZ","1150 MHZ","1200 MHZ","1250 MHZ","1300 MHZ","1350 MHZ","1400 MHZ")

char LO1_Mon[10], LO2_Mon[10];
#web LO1_Mon
#web LO2_Mon

int SS, FDB, FDV, Temp_SS, Temp_FDB, Temp_FDV;
#web SS	select("Choose SS" = 0, "Off", "Normal", "Strong-1", "Strong-2")
#web FDB	select("Choose FDB" = 0, "Off", "On")
#web FDV	select("Choose FDV" = 0, "1", "2", "4", "8")

char SS1_Mon[10], SS2_Mon[10], FDB_Mon[5], FDV_Mon[5], MCM_Clk[10];
#web SS1_Mon
#web SS2_Mon
#web FDB_Mon
#web FDV_Mon
#web MCM_Clk

char msw[5], lsw[5], mswT[5], lswT[5];
#web msw
#web lsw
#web mswT
#web lswT

struct tm  rtc;
unsigned long t0;
char time[10], date[12];
#web time
#web date

int rw[70];
#web rw

char vl[70][10];
#web vl

#web_update LO1, LO2  				Set_LO
#web_update SS			 			Set_SS
#web_update FDB		 				Set_FDB
#web_update FDB		 				Rd_MCM_Clk
#web_update FDV		 				Set_FDV
#web_update FDV       				Rd_MCM_Clk
#web_update msw, lsw  				Set_DMask
#web_update ip, mask, gateway		Set_NW


void Set_LO_Ptrn(unsigned long, int);
void Init();

void Ms_delay(unsigned int delay)
{
	auto unsigned long delay_time;

	delay_time = MS_TIMER + delay;
   while((long)(MS_TIMER - delay_time) < 0 );
}


main()
{
  auto unsigned long scn_dl;

  brdInit();
  sock_init();
  http_init();
  SPIinit();
  Init();

  tcp_reserveport(80);

  ifconfig( IF_ETH0, IFS_DOWN, IFS_IPADDR,aton(MY_IP_ADDR), IFS_NETMASK,aton(MY_NET_MASK), IFS_ROUTER_SET,aton(MY_GATEWAY), IFS_UP,IFS_END);

  while (ifpending(IF_ETH0) == IF_COMING_UP)
   tcp_tick(NULL);


  while(1)
  {
   http_handler();
   costate    // This will do background monitoring in parallel at every SCAN_DELAY miliseconds //
     {
      http_handler();
      tcp_tick(NULL);
     }
    costate    // This will do background monitoring in parallel at every SCAN_DELAY miliseconds //
     {
       scn_dl = MS_TIMER + SCAN_DELAY;
       Ms_delay(1);  // This delay is necessary for proper working of following loop. //
       while(((scn_dl - MS_TIMER) > 0) && ((scn_dl - MS_TIMER) < 1000))
         yield;
        Scan();
     }
  }

}


void Set_LO()
{
  if(!(LO1))
   LO1 = Temp_LO1;
  if(!(LO2))
   LO2 = Temp_LO2;

  sprintf(LO1_Mon,"%d %s",(600 + ((LO1-1)*50)),"MHz");
  sprintf(LO2_Mon,"%d %s",(600 + ((LO2-1)*50)),"MHz");

  Set_LO_Ptrn((600000 + ((LO1-1)*50000)),0);
  Set_LO_Ptrn((600000 + ((LO2-1)*50000)),1);

  Temp_LO1 = LO1;
  Temp_LO2 = LO2;
}


void Init()
{
  int i;

  Temp_LO1 = 1;
  Temp_LO2 = 1;
  Temp_SS =  2;
  Temp_FDB = 2;
  Temp_FDV = 1;
  sprintf(LO1_Mon,"600 MHz");
  sprintf(LO2_Mon,"600 MHz");
  strcpy(SS1_Mon,"Normal");
  strcpy(SS2_Mon,"Normal");
  strcpy(FDB_Mon,"On");
  strcpy(FDV_Mon,"1");
  strcpy(MCM_Clk,"60 MHz");
  strcpy(msw,"0000");
  strcpy(lsw,"0000");
  strcpy(ip,MY_IP_ADDR);
  strcpy(mask,MY_NET_MASK);
  strcpy(gateway,MY_GATEWAY);
  strcpy(mswT, msw);
  strcpy(lswT, lsw);

  for(i=0;i<70;i++)
  {
   rw[i]=0;
   strcpy(vl[i],"0");
  }

  WrPortI(SPCR, &SPCRShadow, 0x84);       // Necessary statement to define Port A as normal Output //
  WrPortI(PADR, &PADRShadow, 0);

  BitWrPortI(PEDDR, &PEDDRShadow, 1, 0);  // Defining SPI_1, SPI_2 as output //
  BitWrPortI(PEDDR, &PEDDRShadow, 1, 1);

  BitWrPortI(PEDR, &PEDRShadow, 1, 0);    // Set Pin PE1, PE2 (Enable for SPI_1, SPI_2) as High //
  BitWrPortI(PEDR, &PEDRShadow, 1, 1);

  BitWrPortI(PEFR, &PEFRShadow, 1, 3);    // Pin PE3 work as alternet output //
  WrPortI(PEALR, &PEALRShadow, 0xC0);     // Pin PE3 set for SPI port D Serial Clock //

  BitWrPortI(PCFR, &PCFRShadow, 1, 0);    // Set Pin PC0 as alternate output : SPI_Tx_D //
  BitWrPortI(PCALR, &PCALRShadow, 0, 0);
  BitWrPortI(PCALR, &PCALRShadow, 0, 1);

  BitWrPortI(PBDDR, &PBDDRShadow, 1, 2);  // Defining Latch & Output Enable pins as output //
  BitWrPortI(PBDDR, &PBDDRShadow, 1, 3);
  BitWrPortI(PBDDR, &PBDDRShadow, 1, 4);
  BitWrPortI(PBDDR, &PBDDRShadow, 1, 5);
  BitWrPortI(PBDDR, &PBDDRShadow, 1, 6);

  BitWrPortI(PBDR, &PBDRShadow, 0, 2);    // Initialising Latch & Output Enable pins //
  BitWrPortI(PBDR, &PBDRShadow, 0, 3);
  BitWrPortI(PBDR, &PBDRShadow, 0, 4);
  BitWrPortI(PBDR, &PBDRShadow, 0, 5);
  BitWrPortI(PBDR, &PBDRShadow, 1, 6);

  BitWrPortI(PEDDR,&PEDDRShadow,1,4);   // Initialize Mux selection pins as output //
  BitWrPortI(PEDDR,&PEDDRShadow,1,5);
  BitWrPortI(PEDDR,&PEDDRShadow,1,6);
  BitWrPortI(PEDDR,&PEDDRShadow,1,7);

  BitWrPortI(PEDR,&PEDRShadow,0,4);    // Initializing Mux selection pins //
  BitWrPortI(PEDR,&PEDRShadow,0,5);
  BitWrPortI(PEDR,&PEDRShadow,0,6);
  BitWrPortI(PEDR,&PEDRShadow,0,7);

  strcpy(lsw,"0000");
  strcpy(msw,"0000");
  Set_DMask();

}


void Scan()
{
 char channel, mux_sel, set_mux_sel;
 float volt;

 for(channel=0; channel<4; channel++)
  {
   for(mux_sel=0; mux_sel<16; mux_sel++)
    {
      set_mux_sel = mux_sel*16; // To shift 4 bits left //

      WrPortI(PEDR, &PEDRShadow, ((RdPortI(PEDR)&0x0f) | set_mux_sel)); // Logic that dont affect other bits //

      rw[channel*16 + mux_sel] = (anaIn(channel, SINGLE, GAINSET));

      volt = (980 - rw[channel*16 + mux_sel])/196.0;

      volt = volt * 1.035;

    /*  if(rw[channel*16 + mux_sel]>980)
      {
        volt = volt/1.036;
      }   */

      sprintf(vl[channel*16 + mux_sel],"%5.2f",volt);
    }
  }

 t0 = read_rtc();

 mktm(&rtc,t0);

 sprintf(time,"%02d:%02d:%02d",rtc.tm_hour,rtc.tm_min,rtc.tm_sec);
 sprintf(date,"%02d-%02d-%d",rtc.tm_mday,rtc.tm_mon,(1900+rtc.tm_year));

}


void Set_LO_Ptrn(unsigned long lo, int Ch)
{
 char LO_Arr[10], Temp_Arr[10],rem[10];
 int padding, cntr_1, i;


 for(cntr_1=0; cntr_1<9; cntr_1++)
	LO_Arr[cntr_1] = '0';

 printf("\n unsigned lo = %ld",lo);

 i=0;
  do
  {
   rem[i] = (lo%16)+48;
   if(rem[i]>57)
   rem[i] = rem[i]+7;
   lo = lo/16;
   i++;
  }while(lo>0);
  rem[i]= 0 ;

  for(cntr_1=0; cntr_1 < strlen(rem); cntr_1++)
  {
    Temp_Arr[i-1] = rem[cntr_1];
    i--;
  }
  Temp_Arr[cntr_1]= 0;

  printf("\nAfter converting to hex : %s",Temp_Arr);

  padding = 9 - strlen(Temp_Arr);

  strcpy(LO_Arr + padding, Temp_Arr);

  LO_Arr[0] = 'K';


 for(cntr_1=0; cntr_1 < strlen(LO_Arr); cntr_1++)
  {
    if((LO_Arr[cntr_1] > 96) && (LO_Arr[cntr_1] < 123))
     LO_Arr[cntr_1] = LO_Arr[cntr_1] - 32;
  }

 strcpy(Temp_Arr, LO_Arr);

 printf("\nSending over SPI (LO_Arr) : %s\n",LO_Arr);

 printf("\n\nBefore making PE%d high : 0x%x",Ch,RdPortI(PEDR));
 BitWrPortI(PEDR, &PEDRShadow, 1, Ch);

 BitWrPortI(PEDR, &PEDRShadow, 0, Ch);
 printf("\nAfter making PE%d low : 0x%x",Ch,RdPortI(PEDR));

 for(i=0;i<5;i++);

 SPIWrite(LO_Arr,10);

 for(i=0;i<5;i++);


 BitWrPortI(PEDR, &PEDRShadow, 1, Ch);
 printf("\nAgain after making PE%d high : 0x%x",Ch,RdPortI(PEDR));
}


void Set_SS()
{
  if(!(SS))
   SS = Temp_SS;

  if(SS == 1)
   {
     WrPortI(GCM1R,NULL,0x00);
     strcpy(SS1_Mon,"Off");
     strcpy(SS2_Mon,"Off");
     Ms_delay(10);
   }
  else if(SS == 2)
   {
     WrPortI(GCM1R,NULL,0x00);
     Ms_delay(10);
     WrPortI(GCM0R,NULL,0x40);
     WrPortI(GCM1R,NULL,0x80);
     strcpy(SS1_Mon,"Normal");
     strcpy(SS2_Mon,"Normal");
   }
  else if(SS == 3)
   {
     WrPortI(GCM1R,NULL,0x00);
     Ms_delay(10);
     WrPortI(GCM0R,NULL,0x00);
     WrPortI(GCM1R,NULL,0x80);
     strcpy(SS1_Mon,"Normal");
     strcpy(SS2_Mon,"Strong");
   }
  else if(SS == 4)
   {
     WrPortI(GCM1R,NULL,0x00);
     Ms_delay(10);
     WrPortI(GCM0R,NULL,0x80);
     WrPortI(GCM1R,NULL,0x80);
     strcpy(SS1_Mon,"Strong");
     strcpy(SS2_Mon,"Normal");
   }
 Temp_SS = SS;
}


void Set_FDB()
{
  if(!(FDB))
   FDB = Temp_FDB;

  if(FDB == 1)
   {
     WrPortI(GCDR,NULL,0x00);
     strcpy(FDB_Mon,"Off");
   }
  else if(FDB == 2)
   {
     WrPortI(GCDR,NULL,0x05);
     strcpy(FDB_Mon,"On");
   }
 Temp_FDB = FDB;
}


void Set_FDV()
{
 if(!(FDV))
   FDV = Temp_FDV;

 if(FDV == 1)
   {
     WrPortI(GCSR,NULL,0x09);
     strcpy(FDV_Mon,"1");
   }
  else if(FDV == 2)
   {
     WrPortI(GCSR,NULL,0x0D);
     strcpy(FDV_Mon,"2");
   }
  else if(FDV == 3)
   {
     WrPortI(GCSR,NULL,0x19);
     strcpy(FDV_Mon,"4");
   }
  else if(FDV == 4)
   {
     WrPortI(GCSR,NULL,0x1D);
     strcpy(FDV_Mon,"6");
   }
  else if(FDV == 5)
   {
     WrPortI(GCSR,NULL,0x01);
     strcpy(FDV_Mon,"8");
   }
 Temp_FDV = FDV;
}


void Rd_MCM_Clk()
{
  int Clock;

  Clock = (30.0*FDB)/FDV;
  sprintf(MCM_Clk,"%d MHz",Clock);
}


void Set_DMask()
{
  int i, MSB_2, LSB_2, MSB_1, LSB_1;

  strcpy(mswT, msw);
  strcpy(lswT, lsw);
  for(i=0;i<sizeof(mswT);i++)
   mswT[i] = toupper(mswT[i]);
  for(i=0;i<sizeof(lswT);i++)
   lswT[i] = toupper(lswT[i]);

  LSB_2 = atox(msw + 2);
  msw[2]=0;
  MSB_2 = atox(msw);    // don't need any shift operation, because atox is done only for two poiter locations //

  LSB_1 = atox(lsw + 2);
  lsw[2]=0;
  MSB_1 = atox(lsw);

  printf("\nMSB_2 LSB_2 MSB_1 LSB_1 : %x %x %x %x", MSB_2, LSB_2, MSB_1, LSB_1);

  // Init Before setting the bits //

  BitWrPortI(PBDR, &PBDRShadow, 1, 6);
  BitWrPortI(PBDR, &PBDRShadow, 0, 2);
  BitWrPortI(PBDR, &PBDRShadow, 0, 3);
  BitWrPortI(PBDR, &PBDRShadow, 0, 4);
  BitWrPortI(PBDR, &PBDRShadow, 0, 5);

  // Set Most Significant Word and Least Significant Word on 32 Bit digital o/ps //

  WrPortI(PADR, &PADRShadow, LSB_1);
  BitWrPortI(PBDR, &PBDRShadow, 1, 2); // Latching value at LSB latch //

 /* BitWrPortI(PBDR, &PBDRShadow, 0, 2);    // Dont use this switching as its creating problem with latch ICs //
  BitWrPortI(PBDR, &PBDRShadow, 1, 2);
  BitWrPortI(PBDR, &PBDRShadow, 0, 2);     */

  WrPortI(PADR, &PADRShadow, MSB_1);
  BitWrPortI(PBDR, &PBDRShadow, 1, 3); // Latching value at LSB latch //

  WrPortI(PADR, &PADRShadow, LSB_2);
  BitWrPortI(PBDR, &PBDRShadow, 1, 4); // Latching value at LSB latch //

  WrPortI(PADR, &PADRShadow, MSB_2);
  BitWrPortI(PBDR, &PBDRShadow, 1, 5); // Latching value at LSB latch //

  BitWrPortI(PBDR, &PBDRShadow, 0, 6); // Enable output of both latches at same time //

}


int atox(char *msk)
{
  int hex_value;
  char mask[5];
  strcpy(mask,msk);

  if((mask[0] < 58) && (mask[0] > 47))
   mask[0] = mask[0] - '0';
  else if((mask[0] > 64) && (mask[0] < 71))
   mask[0] = mask[0] - 'A' + 10;
  else if((mask[0] > 96) && (mask[0] < 103))
   mask[0] = mask[0] - 'a' + 10;
  else
   mask[0] = 0;

  if((mask[1] < 58) && (mask[1] > 47))
   mask[1] = mask[1] - '0';
  else if((mask[1] > 64) && (mask[1] < 71 ))
   mask[1] = mask[1] - 'A' + 10;
  else if((mask[1] > 96) && (mask[1] < 103))
   mask[1] = mask[1] - 'a' + 10;
  else
   mask[1] = 0;


  hex_value = ((mask[0] * 16) + mask[1]);

  return hex_value;
}



void Set_NW()
{
  strcpy(MY_IP_ADDR, ip);
  strcpy(MY_NET_MASK, mask);
  strcpy(MY_GATEWAY, gateway);

  ifconfig( IF_ETH0, IFS_DOWN, IFS_IPADDR,aton(MY_IP_ADDR), IFS_NETMASK,aton(MY_NET_MASK), IFS_ROUTER_SET,aton(MY_GATEWAY), IFS_UP,IFS_END);

  while (ifpending(IF_ETH0) == IF_COMING_UP)
   tcp_tick(NULL);
}
