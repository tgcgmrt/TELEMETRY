// ********************************************************************************** //
// *************************** Program : Online_V2_MCM ****************************** //
// ****************************** Date : 04/08/2014 ********************************* //
// ******************************** Version : V0.5 ********************************** //
// ***** Well structured and web integrated program for IN House development MCM **** //
// ********************************************************************************** //


#class    auto
#memmap   xmem

#use      "rcm43xx.lib"	             // Use with RCM 4300

#use      "adc_ads7870.lib"
#include  "define.c"
#include  "Init.c"
#use	    "dcrtcp.lib"
#use  	 "http.lib"
#use      "spi.lib"


SSPEC_MIMETABLE_START
   SSPEC_MIME(".html","text/html"),
   SSPEC_MIME_FUNC(".xml","text/xml",zhtml_handler),
   SSPEC_MIME_FUNC(".zhtml","text/html",zhtml_handler)
SSPEC_MIMETABLE_END

SSPEC_RESOURCETABLE_START
   SSPEC_RESOURCE_XMEMFILE("/",MCM_Mon_html),
   SSPEC_RESOURCE_XMEMFILE("/Mon_Sum.xml",Mon_Sum_xml),
   SSPEC_RESOURCE_XMEMFILE("/Mon_Raw.xml",Mon_Raw_xml)
SSPEC_RESOURCETABLE_END



static tcp_Socket Socket;



//.... Generating milisecond delay .... //

void Ms_delay(unsigned int delay)
{
	auto unsigned long delay_time;

	delay_time = MS_TIMER + delay;
   while((long)(MS_TIMER - delay_time) < 0 );
}

void cmd_exe();
void bg_mon();
void Set_DMask(char *, char *);
void Set_SS();
void Set_FDB();
void Set_FDV();
void Rd_MCM_Clk();
void Set_RTC(char *);
void Set_LO(unsigned long, char);
int  atox(char *);


void sentinel_mon();
void sentinel_set();
void sentinal_init();
void sentinal_reset();
void sen_mon_sum();


void front_end_mon();
void front_end_set();
void front_end_init();
void front_end_reset();
void fe_mon_sum();


void fiber_optics_mon();
void fiber_optics_set();
void fiber_optics_init();
void fiber_optics_reset();
void of_mon_sum();


void back_end_mon();
void back_end_set();
void back_end_init();
void back_end_reset();
void be_mon_sum();


void mcm_mon();
void mcm_set();
void mcm_init();
void mcm_reset();




// .... Opening Server Socket at desired port address .... //

cofunc int mcm_clnt()
{
   int i; // temperory used to print received structure //

   int port, write_bytes, read_bytes, wait_var;
   longword host;

   ifconfig( IF_ETH0, IFS_DOWN, IFS_IPADDR,aton(MY_IP_ADDR), IFS_NETMASK,aton(MY_NET_MASK), IFS_ROUTER_SET,aton(MY_GATEWAY), IFS_UP, IFS_END);

   while (ifpending(IF_ETH0) == IF_COMING_UP)
         tcp_tick(NULL);

   if(!(host = inet_addr(SERVER_ADDR)))
   {
      puts("\nCould not resolve host");
      exit(3);
   }
   printf("\nHost hex address %lx\n",host);

   port = atoi(SERVER_PORT);

   printf("Attempting to open '%s' on port %u\n\r", SERVER_ADDR, port );

   while( ! tcp_open(&Socket, 0, host, port, NULL))
   {
     printf("\nUnable to open TCP session");
     tcp_tick(NULL);
   }


   wait_var = 0;

   while((!sock_established(&Socket) && sock_bytesready(&Socket)== -1))
    {
      http_handler();
      tcp_tick(NULL);
      wait_var++;
      if(wait_var == 100)
      {
        tcp_open(&Socket, 0, host, port, NULL);
        wait_var = 0;
      }
      yield;
    }
   printf("\nSocket Established");

   if(sock_established(&Socket))
   {
    read_bytes = 0;
    do{

       if(sock_bytesready(&Socket) > 0)
       {
         read_bytes = sock_read(&Socket, &pc_cmd, pc_cmd_size);

         printf("\nMCM has read command of %d bytes",read_bytes);
         printf("\n Sequence Number : %ld",pc_cmd.Sequence_No);
         printf("\n Time Stamp : %s",pc_cmd.TimeStamp);
         printf("\n System Name : %s",pc_cmd.System_Name);
         printf("\n Operation Name : %s",pc_cmd.Operation_Name);

         for(i=0; i< pc_cmd.Total_Parameter; i++)
         {
          printf("\n Parameter Name : %s",pc_cmd.Parameter_Name[i]);
          if(strlen(pc_cmd.Parameter_Name[i])<5)
           printf("\t");
          printf("\t\t\t%s",pc_cmd.Argument_Ch1[i]);
          printf("\t%s",pc_cmd.Argument_Ch2[i]);
         }

         cmd_exe();  // Execution of command in this function //
         bg_mon();

         write_bytes = sock_write(&Socket, &mcm_resp, mcm_resp_size);
         printf("\nMCM has sent response of %d bytes \n",write_bytes);

         Struct_Init();
       }
       read_bytes = 0;
       yield;
      }while(tcp_tick(&Socket));    // This loop continuously listens over socket for incoming command //
   }

   sock_close(&Socket);
	printf("\nConnection closed for port-%d",port);

   return 0;
}


// ..... Main start .... //
main()
{
  auto unsigned long scn_dl;

  brdInit();
  SPIinit();
  PortInit();
  sock_init();
  http_init();
  Struct_Init();
  ADC_Init();
  Init();
  rd_MCM_addr();


  tcp_reserveport(80);

  while(1)
  {

   http_handler();

   costate    // This will open client socket at port 5000 //
    {
      wfd mcm_clnt();
    }

   costate    // This will do background monitoring in parallel at every SCAN_DELAY miliseconds //
    {
      scn_dl = MS_TIMER + SCAN_DELAY;
      Ms_delay(1);  // This delay is necessary for proper working of following loop. //
      while(((scn_dl - MS_TIMER) > 0) && ((scn_dl - MS_TIMER) < 900))
        yield;
       bg_mon();
    }

   costate    // This costatement run web server in parallel //
    {
      http_handler();
      tcp_tick(NULL);
    }

   costate
    {
           // Add any parallel task here. //
    }
  }
}



void cmd_exe()
{
  Init();

  mcm_resp.Response_Type = 1;

  mcm_resp.Sequence_No = pc_cmd.Sequence_No;

  strcpy(mcm_resp.TimeStamp, pc_cmd.TimeStamp);

  strcpy(mcm_resp.System_Name, pc_cmd.System_Name);

  // strcpy(mcm_resp.Mon_Raw[0], "1000");

  strcpy(mcm_resp.Mon_Sum[0], "No summery !!");

  // strcpy(mcm_resp.Response_Message[0],"MCM received command");

  if(!strcmp(pc_cmd.System_Name,System_1))
  {
    strcpy(mcm_resp.Response_Message[0],"System validated : Sentinel");

    strcpy(webpg_mon.sys_name,"SENTINEL");

     if(!strcmp(pc_cmd.Operation_Name,Opr_1))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Sentinal Monitoring");

       sentinel_mon();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_2))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Sentinal Controlling");

       sentinel_set();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_3))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Sentinal Initialize");

       sentinal_init();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_4))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Sentinal Reset");

       sentinal_reset();
     }

     else
     {
       strcpy(mcm_resp.Response_Message[1],"Sentinal Command Invalid");

       mcm_resp.Total_Resp_Msg = 2;
     }
  }


  else if(!strcmp(pc_cmd.System_Name,System_2))
  {
    strcpy(mcm_resp.Response_Message[0],"System validated : Front End");

    strcpy(webpg_mon.sys_name,"FRONT END");

     if(!strcmp(pc_cmd.Operation_Name,Opr_1))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Front End Monitoring");

       front_end_mon();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_2))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Front End Controlling");

       front_end_set();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_3))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Front End Initialize");

       front_end_init();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_4))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Front End Reset");

       front_end_reset();
     }

     else
     {
       strcpy(mcm_resp.Response_Message[1],"Front End Command Invalid");

       mcm_resp.Total_Resp_Msg = 2;
     }
  }


  else if(!strcmp(pc_cmd.System_Name,System_3))
  {
    strcpy(mcm_resp.Response_Message[0],"System validated : Fiber Optics");

    strcpy(webpg_mon.sys_name,"FIBER OPTICS");

     if(!strcmp(pc_cmd.Operation_Name,Opr_1))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Fiber optics Monitoring");

       fiber_optics_mon();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_2))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Fiber optics Controlling");

       fiber_optics_set();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_3))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Fiber optics Initialize");

       fiber_optics_init();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_4))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Fiber optics Reset");

       fiber_optics_reset();
     }

     else
     {
       strcpy(mcm_resp.Response_Message[1],"Fiber optics Command Invalid");

       mcm_resp.Total_Resp_Msg = 2;
     }
  }


  else if(!strcmp(pc_cmd.System_Name,System_4))
  {
    strcpy(mcm_resp.Response_Message[0],"System validated : Back End");

    strcpy(webpg_mon.sys_name,"ANALOG BACK END");

     if(!strcmp(pc_cmd.Operation_Name,Opr_1))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Back End Monitoring");

       back_end_mon();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_2))
     {

       strcpy(mcm_resp.Response_Message[1],"Command validated : Back End Controlling");

       back_end_set();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_3))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Back End Initialize");

       back_end_init();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_4))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Back End Reset");

       back_end_reset();
     }

     else
     {
       strcpy(mcm_resp.Response_Message[1],"Back End Command Invalid");

       mcm_resp.Total_Resp_Msg = 2;
     }
  }

  else if(!strcmp(pc_cmd.System_Name,System_5))
  {
    strcpy(mcm_resp.Response_Message[0],"System validated : Test Sys");

    strcpy(webpg_mon.sys_name,"TEST SYSTEM");

     if(!strcmp(pc_cmd.Operation_Name,Opr_1))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Test Sys Monitoring");

       mcm_mon();

     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_2))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Test Sys Controlling");

       mcm_set();

       mcm_resp.Total_Resp_Msg = 2;
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_3))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Test Sys Initialize");

        mcm_init();
     }

     else if(!strcmp(pc_cmd.Operation_Name,Opr_4))
     {
       strcpy(mcm_resp.Response_Message[1],"Command validated : Test Sys Reset");

        mcm_reset();
     }

     else
     {
       strcpy(mcm_resp.Response_Message[1],"Test Sys Command Invalid");

       mcm_resp.Total_Resp_Msg = 2;
     }
  }

  else
  {
     strcpy(mcm_resp.Response_Message[0],"System Invalid : ??");

     mcm_resp.Total_Resp_Msg = 1;
  }


}




// ****** Doing background monitoring tasks and event generation ****** //

void bg_mon()
{
  int channel, mux_sel, set_mux_sel;
  float tmp, volt;
  unsigned long t0;

  for(channel=0; channel<4; channel++)
  {
   for(mux_sel=0; mux_sel<16; mux_sel++)
    {
      set_mux_sel = mux_sel*16;

      WrPortI(PEDR, &PEDRShadow, ((RdPortI(PEDR)&0x0f) | set_mux_sel));

      mon_arr[channel*16 + mux_sel] = (anaIn(channel, SINGLE, GAINSET));
      sprintf(mcm_resp.Mon_Raw[channel*16 + mux_sel], "%d", mon_arr[channel*16 + mux_sel]);

      volt = (980 - mon_arr[channel*16 + mux_sel])/196.0;
      sprintf(mon_vlt[channel*16 + mux_sel],"%5.2f",volt);

    }
  }

  t0 = read_rtc();

  mktm(&rtc,t0);

  sprintf(RTC_time,"%02d : %02d : %02d",rtc.tm_hour,rtc.tm_min,rtc.tm_sec);

  sprintf(RTC_date,"%02d - %02d - %04d",rtc.tm_mday,rtc.tm_mon,(1900+rtc.tm_year));
}




// **** After initialising port bits in PortInit(), 32 bit digital mask will be set here **** //

void Set_DMask(char * arg1, char * arg2)
{
  int MSB_2, LSB_2, MSB_1, LSB_1;

  strcpy(msw,arg1);
  strcpy(lsw,arg2);

  LSB_2 = atox(msw + 2);
  MSB_2 = atox(msw);    // don't need any shift operation, because atox is done only for two poiter locations //

  LSB_1 = atox(lsw + 2);
  MSB_1 = atox(lsw);

  BitWrPortI(PBDR, &PBDRShadow, 1, 6);
  BitWrPortI(PBDR, &PBDRShadow, 0, 2);
  BitWrPortI(PBDR, &PBDRShadow, 0, 3);
  BitWrPortI(PBDR, &PBDRShadow, 0, 4);
  BitWrPortI(PBDR, &PBDRShadow, 0, 5);

  printf("\nMSB_2 LSB_2 MSB_1 LSB_1 : %x %x %x %x", MSB_2, LSB_2, MSB_1, LSB_1);

  // Set Most Significant Word and Least Significant Word on 32 Bit digital o/ps //
  WrPortI(PADR, &PADRShadow, LSB_1);
  BitWrPortI(PBDR, &PBDRShadow, 1, 2); // Latching value at LSB latch //

  WrPortI(PADR, &PADRShadow, MSB_1);
  BitWrPortI(PBDR, &PBDRShadow, 1, 3); // Latching value at LSB latch //

  WrPortI(PADR, &PADRShadow, LSB_2);
  BitWrPortI(PBDR, &PBDRShadow, 1, 4); // Latching value at LSB latch //

  WrPortI(PADR, &PADRShadow, MSB_2);
  BitWrPortI(PBDR, &PBDRShadow, 1, 5); // Latching value at LSB latch //

  BitWrPortI(PBDR, &PBDRShadow, 0, 6); // Enable output of both latches at same time //
}




//**** Setting MCM Spectrum Spreader ***** //

void Set_SS()
{

  if(SS == 0)
   {
     WrPortI(GCM1R,NULL,0x00);
     strcpy(SS1_Mon,"Off");
     strcpy(SS2_Mon,"Off");
     Ms_delay(10);
   }
  else if(SS == 1)
   {
     WrPortI(GCM1R,NULL,0x00);
     Ms_delay(10);
     WrPortI(GCM0R,NULL,0x40);
     WrPortI(GCM1R,NULL,0x80);
     strcpy(SS1_Mon,"Normal");
     strcpy(SS2_Mon,"Normal");
   }
  else if(SS == 2)
   {
     WrPortI(GCM1R,NULL,0x00);
     Ms_delay(10);
     WrPortI(GCM0R,NULL,0x00);
     WrPortI(GCM1R,NULL,0x80);
     strcpy(SS1_Mon,"Normal");
     strcpy(SS2_Mon,"Strong");
   }
  else if(SS == 3)
   {
     WrPortI(GCM1R,NULL,0x00);
     Ms_delay(10);
     WrPortI(GCM0R,NULL,0x80);
     WrPortI(GCM1R,NULL,0x80);
     strcpy(SS1_Mon,"Strong");
     strcpy(SS2_Mon,"Normal");
   }
}





//**** Setting MCM Clock Frequency Doubler ***** //

void Set_FDB()
{

  if(FDB == 0)
   {
     WrPortI(GCDR,NULL,0x00);
     strcpy(FDB_Mon,"Off");
   }
  else if(FDB == 1)
   {
     WrPortI(GCDR,NULL,0x05);
     strcpy(FDB_Mon,"On");
   }
}




//**** Setting MCM Clock Frequency Divider **** //

void Set_FDV()
{

 if(FDV == 1)
   {
     WrPortI(GCSR,NULL,0x09);
     strcpy(FDV_Mon,"1");
   }
  else if(FDV == 2)
   {
     WrPortI(GCSR,NULL,0x0D);
     strcpy(FDV_Mon,"2");
   }
  else if(FDV == 4)
   {
     WrPortI(GCSR,NULL,0x19);
     strcpy(FDV_Mon,"4");
   }
  else if(FDV == 6)
   {
     WrPortI(GCSR,NULL,0x1D);
     strcpy(FDV_Mon,"6");
   }
  else if(FDV == 8)
   {
     WrPortI(GCSR,NULL,0x01);
     strcpy(FDV_Mon,"8");
   }
}




// **** Reading MCM Clock Frequency **** //

void Rd_MCM_Clk()
{

  MCM_Clk_Frq = (30.0*(FDB+1))/FDV;
  sprintf(MCM_Clk,"%5.2f MHz",MCM_Clk_Frq);
}




// **** This function will set RTC to value provided within Init command **** //

void Set_RTC(char * rtc_str)
{
  char set_rtc[32], month1[5];
  int i;

  char month[][4] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

  strcpy(set_rtc,rtc_str);

  printf("\nRTC is set to : %s",rtc_str);
  printf("\nRTC is set to : %s",set_rtc);

  // Setting RTC is hard-coded, follows timestamp formate : dd-Mon-yyyy hh:mm:ss//

  rtc_str = set_rtc;

  set_rtc[2]=0;
  set_rtc[6]=0;
  set_rtc[11]=0;
  set_rtc[14]=0;
  set_rtc[17]=0;
  set_rtc[20]=0;


  rtc_str  = rtc_str + 18;
    rtc.tm_sec = atoi(rtc_str);            // storing second //

  rtc_str  = rtc_str - 3;
    rtc.tm_min = atoi(rtc_str);            // storing minute //

  rtc_str  = rtc_str - 3;
    rtc.tm_hour = atoi(rtc_str);           // storing hour //


  rtc_str  = rtc_str - 5;
   rtc.tm_year =  atoi(rtc_str) - 1900;    // storing year //


  rtc_str  = rtc_str - 4;
   for(i=0; i<12; i++)
    {
     if(!strcmp(rtc_str,month[i]))
      sprintf(month1, "%02d", i);      // storing month //
      rtc.tm_mon = atoi(month1);
    }

  rtc_str  = rtc_str - 3;
   rtc.tm_mday =  atoi(rtc_str);           // storing day //

  tm_wr(&rtc);								  	    // Writing to RTC //
  SEC_TIMER = mktime(&rtc);                // mktime() is required to read current value correctly using tm_read()//
}




// **** Setting LO Frequency by sending SPI bit patterns **** //

void Set_LO(unsigned long lo, char Ch)
{
 char LO_Arr[10], Temp_Arr[10],rem[10];
 int padding, cntr_1, i;


 for(cntr_1=0; cntr_1<9; cntr_1++)
	LO_Arr[cntr_1] = '0';

 printf("\n unsigned lo = %ld",lo);

 i=0;
  do
  {
   rem[i] = (lo%16)+48;
   if(rem[i]>57)
   rem[i] = rem[i]+7;
   lo = lo/16;
   i++;
  } while(lo>0);

  rem[i]= 0 ;

  for(cntr_1=0; cntr_1 < strlen(rem); cntr_1++)
  {
    Temp_Arr[i-1] = rem[cntr_1];
    i--;
  }
  Temp_Arr[cntr_1]= 0;

  printf("\nAfter converting to hex : %s",Temp_Arr);

  padding = 9 - strlen(Temp_Arr);

  strcpy(LO_Arr + padding, Temp_Arr);

  LO_Arr[0] = 'K';


 for(cntr_1=0; cntr_1 < strlen(LO_Arr); cntr_1++)
  {
    if((LO_Arr[cntr_1] > 96) && (LO_Arr[cntr_1] < 123))
     LO_Arr[cntr_1] = LO_Arr[cntr_1] - 32;
  }

 strcpy(Temp_Arr, LO_Arr);

 printf("\nSending over SPI (LO_Arr) : %s\n",LO_Arr);

 BitWrPortI(PEDR, &PEDRShadow, 1, Ch);

 BitWrPortI(PEDR, &PEDRShadow, 0, Ch);

 for(i=0;i<10;i++);

 SPIWrite(LO_Arr,10);

 for(i=0;i<10;i++);

 BitWrPortI(PEDR, &PEDRShadow, 1, Ch);

}




// **** Converting String to Hex value **** //

int atox(char *msk)
{
  int hex_value;
  char mask[3];

  strcpy(mask,msk);

  if((mask[0] < 58) && (mask[0] > 47))
   mask[0] = mask[0] - '0';
  else if((mask[0] > 64) && (mask[0] < 71))
   mask[0] = mask[0] - 'A' + 10;
  else if((mask[0] > 96) && (mask[0] < 103))
   mask[0] = mask[0] - 'a' + 10;
  else
   mask[0] = 0;

  if((mask[1] < 58) && (mask[1] > 47))
   mask[1] = mask[1] - '0';
  else if((mask[1] > 64) && (mask[1] < 71 ))
   mask[1] = mask[1] - 'A' + 10;
  else if((mask[1] > 96) && (mask[1] < 103))
   mask[1] = mask[1] - 'a' + 10;
  else
   mask[1] = 0;


  hex_value = ((mask[0] * 16) + mask[1]);

  return hex_value;
}




/****************************************************************/
/****************** Tasks For Sentinel System *******************/
/****************************************************************/

void sentinel_mon()
{

  // Code for Back End Monitoring and Decoding //

  sprintf(mcm_resp.Response_Message[2],"Sentinel Monitoring Done");
  mcm_resp.Total_Resp_Msg = 3;
}


void sentinel_set()
{
  char i,j;
  char Para_invalid[15];

  for(i=0; i < pc_cmd.Total_Parameter; i++)
  {
   for(j=0; j < SEN_Para_No; j++)
   {
    if(!strcmp(pc_cmd.Parameter_Name[i], SEN_Para[j]))
    {
      switch(j)
      {
        case 0 :  sprintf(mcm_resp.Response_Message[2],"Digital Mask : %s %s",pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  Set_DMask(pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);

                  strcpy(webpg_mon.sys_para[0],"Digital Mask");
    					strcpy(webpg_mon.arg1[0],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[0],pc_cmd.Argument_Ch2[i]);

        				break;

        default : break;
      }
      Para_invalid[i] = 0;
      break;
    } // if end
    else
    {
      Para_invalid[i] = 1;
    }
   }  // for - j end
  }   // for - i end

  for(i=0; i < SEN_Para_No; i++)
  {
   if(Para_invalid[i])
   {
     sprintf(mcm_resp.Response_Message[i+2],"Parameter : %s Invalid",pc_cmd.Parameter_Name[i]);
   }
  }
  mcm_resp.Total_Resp_Msg =  SEN_Para_No + 2;
}


void sentinal_init()
{
  Set_RTC(pc_cmd.TimeStamp);
  sprintf(mcm_resp.Response_Message[2],"Sentinel Initialized");

  mcm_resp.Total_Resp_Msg = 3;

}


void sentinal_reset()
{
  sprintf(mcm_resp.Response_Message[2],"Sentinel Reset done");
  mcm_resp.Total_Resp_Msg = 3;

}


void sen_mon_sum()
{

}




/****************************************************************/
/****************** Tasks For Front End System ******************/
/****************************************************************/

void front_end_mon()
{

  // Code for Back End Monitoring and Decoding //

  sprintf(mcm_resp.Response_Message[2],"Front End Monitoring Done");
  mcm_resp.Total_Resp_Msg = 3;
}


void front_end_set()
{
 char i,j;
 char Para_invalid[15];

  for(i=0; i < pc_cmd.Total_Parameter; i++)
  {
   for(j=0; j < FE_Para_No; j++)
   {
    if(!strcmp(pc_cmd.Parameter_Name[i], FE_Para[j]))
    {
      switch(j)
      {
        case 0 :  sprintf(mcm_resp.Response_Message[2],"Calibration Niose : %s %s",pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[0],"Calibration Noise");
    					strcpy(webpg_mon.arg1[0],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[0],pc_cmd.Argument_Ch2[i]);
                  break;

        case 1 :  sprintf(mcm_resp.Response_Message[3],"RF : %s %s",pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[1],"RF");
    					strcpy(webpg_mon.arg1[1],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[1],pc_cmd.Argument_Ch2[i]);
                  break;

        case 2 :  sprintf(mcm_resp.Response_Message[4],"Filter : %s %s",pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[2],"Filter");
    					strcpy(webpg_mon.arg1[2],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[2],pc_cmd.Argument_Ch2[i]);
        				break;

        case 3 :  sprintf(mcm_resp.Response_Message[5],"Filter for L-Band : %s %s",pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[3],"Filter L-Band");
    					sprintf(webpg_mon.arg1[3],"%s MHz",pc_cmd.Argument_Ch1[i]);
    					sprintf(webpg_mon.arg2[3],"%s MHz",pc_cmd.Argument_Ch2[i]);
        				break;

        case 4 :  sprintf(mcm_resp.Response_Message[6],"Band Selected : %s %s",pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[4],"Band Selection");
    					sprintf(webpg_mon.arg1[4],"%s MHz",pc_cmd.Argument_Ch1[i]);
    					sprintf(webpg_mon.arg2[4],"%s MHz",pc_cmd.Argument_Ch2[i]);
        				break;

        case 5 :  sprintf(mcm_resp.Response_Message[7],"Solar Attenuation : %s %s",pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[5],"Solar Attenuation");
    					sprintf(webpg_mon.arg1[5],"%s dB",pc_cmd.Argument_Ch1[i]);
    					sprintf(webpg_mon.arg2[5],"%s dB",pc_cmd.Argument_Ch2[i]);
        				break;

        case 6 :  sprintf(mcm_resp.Response_Message[8],"Channel : %s",pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.sys_para[6],"Channel");
    					strcpy(webpg_mon.arg1[6],pc_cmd.Argument_Ch1[i]);
        				break;

        default : break;

      }
      Para_invalid[i] = 0;
      break;
    } // if end
    else
    {
      Para_invalid[i] = 1;
    }
   }  // for - j end
  }   // for - i end

  for(i=0; i < FE_Para_No; i++)
  {
   if(Para_invalid[i])
   {
     sprintf(mcm_resp.Response_Message[i+2],"Parameter : %s Invalid",pc_cmd.Parameter_Name[i]);
   }
  }
  mcm_resp.Total_Resp_Msg =  FE_Para_No + 2;
}


void front_end_init()
{
  Set_RTC(pc_cmd.TimeStamp);
  sprintf(mcm_resp.Response_Message[2],"Front End Initialized");
  mcm_resp.Total_Resp_Msg = 3;
}


void front_end_reset()
{
  sprintf(mcm_resp.Response_Message[2],"Front End Reset Done");
  mcm_resp.Total_Resp_Msg = 3;
}


void fe_mon_sum()
{

}




/****************************************************************/
/**************** Tasks For Fiber Optics System *****************/
/****************************************************************/

void fiber_optics_mon()
{

  // Code for Back End Monitoring and Decoding //

  sprintf(mcm_resp.Response_Message[2],"Fiber Optics Monitoring Done");
  mcm_resp.Total_Resp_Msg = 3;
}


void fiber_optics_set()
{
  char i,j;
  char Para_invalid[15];

  for(i=0; i < pc_cmd.Total_Parameter; i++)
  {
   for(j=0; j < OF_Para_No; j++)
   {
    if(!strcmp(pc_cmd.Parameter_Name[i], OF_Para[j]))
    {
      switch(j)
      {
        case 0 :  sprintf(mcm_resp.Response_Message[2],"RF Attenuation : %s %s",pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[0],"RF Attenuation");
    					sprintf(webpg_mon.arg1[0],"%s dB",pc_cmd.Argument_Ch1[i]);
    					sprintf(webpg_mon.arg2[0],"%s dB",pc_cmd.Argument_Ch2[i]);
        				break;

        default : break;
      }
      Para_invalid[i] = 0;
      break;
    } // if end
    else
    {
      Para_invalid[i] = 1;
    }
   }  // for - j end
  }   // for - i end

  for(i=0; i < OF_Para_No; i++)
  {
   if(Para_invalid[i])
   {
     sprintf(mcm_resp.Response_Message[i+2],"Parameter : %s Invalid",pc_cmd.Parameter_Name[i]);
   }
  }
  mcm_resp.Total_Resp_Msg =  OF_Para_No + 2;
}


void fiber_optics_init()
{
  Set_RTC(pc_cmd.TimeStamp);
  sprintf(mcm_resp.Response_Message[2],"Fiber Optics Initialized");
  mcm_resp.Total_Resp_Msg = 3;

}


void fiber_optics_reset()
{
  sprintf(mcm_resp.Response_Message[2],"Fiber Optics Reset Done");
  mcm_resp.Total_Resp_Msg = 3;
}


void of_mon_sum()
{

}




/****************************************************************/
/****************** Tasks For Back End System *******************/
/****************************************************************/

void back_end_mon()
{

  // Code for Back End Monitoring and Decoding //

  sprintf(mcm_resp.Response_Message[2],"Back End Monitoring Done");
  mcm_resp.Total_Resp_Msg = 3;
}


void back_end_set()
{
  char i, j;
  char Para_invalid[15];
  int fltr1, fltr2, lpf1, lpf2;
  float attn1, attn2;
  unsigned long Dmask, lo1, lo2;


  for(i=0; i < pc_cmd.Total_Parameter; i++)
  {
   for(j=0; j < BE_Para_No; j++)
   {
    if(!strcmp(pc_cmd.Parameter_Name[i], BE_Para[j]))
    {
      switch(j)
      {
        case 0 : 	lo1 = atol(pc_cmd.Argument_Ch1[i]);
    			   	lo2 = atol(pc_cmd.Argument_Ch2[i]);

    			   	Set_LO(lo1,0);
    			   	Set_LO(lo2,1);

    			   	sprintf(mcm_resp.Response_Message[2],"LO SET : %6.1f MHz, %6.1f MHz", lo1/1000.0, lo2/1000.0);
                  strcpy(webpg_mon.sys_para[0],"LO Frequency");
    					sprintf(webpg_mon.arg1[0],"%6.1f MHz",lo1/1000.0);
    					sprintf(webpg_mon.arg2[0],"%6.1f MHz",lo2/1000.0);
                  break;

        case 1 :  attn1 = atof(pc_cmd.Argument_Ch1[i]);
					   attn2 = atof(pc_cmd.Argument_Ch2[i]);
					   sprintf(mcm_resp.Response_Message[3],"Attenuation SET : %5.1f dB, %5.1f dB", attn1, attn2);
                  strcpy(webpg_mon.sys_para[1],"Attenuation");
    					sprintf(webpg_mon.arg1[1],"%5.1f dB",attn1);
    					sprintf(webpg_mon.arg2[1],"%5.1f dB",attn2);
					   break;

        case 2 :  fltr1 = atoi(pc_cmd.Argument_Ch1[i]);
				      fltr2 = atoi(pc_cmd.Argument_Ch2[i]);
				      sprintf(mcm_resp.Response_Message[4],"Filter SET : %d , %d", fltr1, fltr2);
                  strcpy(webpg_mon.sys_para[2],"Filter");
    					strcpy(webpg_mon.arg1[2],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[2],pc_cmd.Argument_Ch2[i]);
				      break;

        case 3 :  lpf1 = atoi(pc_cmd.Argument_Ch1[i]);
				      lpf2 = atoi(pc_cmd.Argument_Ch2[i]);
				      sprintf(mcm_resp.Response_Message[5],"LPF SET : %d , %d", lpf1, lpf2);
                  strcpy(webpg_mon.sys_para[3],"Low pass Filter");
    					strcpy(webpg_mon.arg1[3],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[3],pc_cmd.Argument_Ch2[i]);
				      break;

        case 4 :  sprintf(mcm_resp.Response_Message[6],"Source: %s %s", pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[4],"Source");
    					strcpy(webpg_mon.arg1[4],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[4]," ");
    					break;

        case 5 :  sprintf(mcm_resp.Response_Message[7],"Signal : %s %s", pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[5],"Signal");
    					strcpy(webpg_mon.arg1[5],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[5]," ");
				      break;

        case 6 :  sprintf(mcm_resp.Response_Message[8],"Path : %s %s", pc_cmd.Argument_Ch1[i], pc_cmd.Argument_Ch2[i]);
                  strcpy(webpg_mon.sys_para[6],"Path");
    					strcpy(webpg_mon.arg1[6],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[6]," ");
				      break;

        case 7 :  sprintf(mcm_resp.Response_Message[9],"Channel : %s", pc_cmd.Argument_Ch1[i]);
                  strcpy(webpg_mon.sys_para[7],"Channel");
    					strcpy(webpg_mon.arg1[7],pc_cmd.Argument_Ch1[i]);
    					strcpy(webpg_mon.arg2[7]," ");
				      break;

        default : break;
      }
      Para_invalid[i] = 0;
      break;
    } // if end
    else
    {
      Para_invalid[i] = 1;
    }
   }  // for - j end

  }   // for - i end


  for(i=0; i < BE_Para_No; i++)
  {
   if(Para_invalid[i])
   {
     sprintf(mcm_resp.Response_Message[i+2],"Parameter : %s Invalid",pc_cmd.Parameter_Name[i]);
   }
  }
  mcm_resp.Total_Resp_Msg =  BE_Para_No + 2;
}


void back_end_init()
{
  Set_RTC(pc_cmd.TimeStamp);

  sprintf(mcm_resp.Response_Message[2],"Back End Initialized");
  mcm_resp.Total_Resp_Msg = 3;
}


void back_end_reset()
{
  sprintf(mcm_resp.Response_Message[2],"Back End Reset Done");
  mcm_resp.Total_Resp_Msg = 3;
}


void be_mon_sum()
{

}




/****************************************************************/
/********************* Tasks For Self Test **********************/
/****************************************************************/

void mcm_mon()
{

  sprintf(mcm_resp.Response_Message[2],"MCM Monitoring Done");
  mcm_resp.Total_Resp_Msg = 3;
}


void mcm_set()
{
  char i, j;
  char Para_invalid[15];


  for(i=0; i < pc_cmd.Total_Parameter; i++)
  {
   for(j=0; j < MCM_Para_No; j++)
   {
    if(!strcmp(pc_cmd.Parameter_Name[i], MCM_Para[j]))
    {
      switch(j)
      {
        case 0 : 	SS = atoi(pc_cmd.Argument_Ch1[i]);

                  Set_SS();

                  if(SS == 0)
    			       strcpy(mcm_resp.Response_Message[2],"Spectrum Spreader Set : Off    Off");

                  else if(SS == 1)
    			   	 strcpy(mcm_resp.Response_Message[2],"Spectrum Spreader Set : Normal    Normal");

                  else if(SS == 2)
    			   	 strcpy(mcm_resp.Response_Message[2],"Spectrum Spreader Set : Normal    Strong");

                  else if(SS == 3)
    			   	 strcpy(mcm_resp.Response_Message[2],"Spectrum Spreader Set : Strong    Normal");

                  else
                   strcpy(mcm_resp.Response_Message[2],"Spectrum Spreader : Argument Invalid");

                  break;

        case 1 :  FDB = atoi(pc_cmd.Argument_Ch1[i]);

        				Set_FDB();

        				if(FDB == 0)
					    strcpy(mcm_resp.Response_Message[3],"Frequency Doubler : Off");

        				else if(FDB == 1)
					    strcpy(mcm_resp.Response_Message[3],"Frequency Doubler : On");

                  else
                   strcpy(mcm_resp.Response_Message[3],"Frequency Doubler : Argument Invalid");

					   break;

        case 2 :  FDV = atoi(pc_cmd.Argument_Ch1[i]);

        				Set_FDV();

				      sprintf(mcm_resp.Response_Message[4],"Frequency Divided By : %d",FDV);

				      break;

        default : break;
      }
      Para_invalid[i] = 0;
      break;

    } // if end
    else
    {
      Para_invalid[i] = 1;
    }
   }  // for - j end

  }   // for - i end


  for(i=0; i < MCM_Para_No; i++)
  {
   if(Para_invalid[i])
   {
     sprintf(mcm_resp.Response_Message[i+2],"Parameter : %s Invalid",pc_cmd.Parameter_Name[i]);
   }
  }


  Rd_MCM_Clk();

  sprintf(mcm_resp.Response_Message[MCM_Para_No + 2],"Clock Frequency : %5.2f MHz",MCM_Clk_Frq);

  mcm_resp.Total_Resp_Msg =  MCM_Para_No + 3;

}


void mcm_init()
{
  Set_RTC(pc_cmd.TimeStamp);

  sprintf(mcm_resp.Response_Message[2],"MCM Initialized");
  mcm_resp.Total_Resp_Msg = 3;
}


void mcm_reset()
{
  sprintf(mcm_resp.Response_Message[2],"MCM Reset Done");
  mcm_resp.Total_Resp_Msg = 3;
}
