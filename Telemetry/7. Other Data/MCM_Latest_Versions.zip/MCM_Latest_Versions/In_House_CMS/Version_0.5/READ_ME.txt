1 Open the .dcp file with DCxx.xx dynamic C compiler.

2 If project explorer window is not open, then open it. Which is under Windows. 

3 First check location of main_v05.c file in project explorer window. If it is not same as folder's location For Exa. : C:\User\Mahadev\Desktop\Folder_Name

4 Run project from green trigone button at Project Explorer window, which is generally at bottom.  (Remember not to click button in menu bar)

5 To change the MCM IP address, go to define.c file. There is one pragma called : #define MY_IP_ADDR 192.168.8.xx

6 Keep subnet address : 255.255.255.0, dont change it.

7 Dont forget to change gateway address according to IP and subnet. For example MCM IP : 192.168.33.3 then #define MY_GATEWAY 192.168.33.1

8 Also check Server address as well as port id if it is required to change.
